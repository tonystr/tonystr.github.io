music: http://www.purple-planet.com/
sounds: https://freesound.org/